package com.partha.bootProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
