package com.partha.bootProject.web.service;

import org.springframework.stereotype.Component;

@Component
public class LoginService {
	public boolean validateUser(String userId, String password) {
		return userId.equalsIgnoreCase("partha") && password.equalsIgnoreCase("partha123");
	}

}
